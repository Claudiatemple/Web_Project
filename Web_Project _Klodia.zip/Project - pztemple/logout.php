<?php
    //I watched some tutorials and learn from a senior collegue how to build this
    session_aborting();
    header("location: login.php");
    //If there is any Error I wish to learn more of this later 
?>